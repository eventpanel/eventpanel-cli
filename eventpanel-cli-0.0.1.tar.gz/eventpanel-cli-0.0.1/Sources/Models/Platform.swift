//
//  Language.swift
//  eventpanel
//
//  Created by Sukhanov Evgenii on 03.05.2025.
//

enum Language: String, Codable {
    case swift
}
